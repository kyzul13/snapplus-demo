"use client";

import { useState } from "react";

const features = [
  ["👀", "Revoir les stories", "Une maquette de présentation des options premium."],
  ["🌟", "Personnalisation", "Aperçu de thèmes et d'éléments visuels personnalisables."],
  ["🎨", "Options exclusives", "Présentez vos avantages dans une interface moderne."]
];

export default function Home() {
  const [step, setStep] = useState(0);
  const [showInfo, setShowInfo] = useState(false);

  return (
    <main>
      <div className="topline"><span className="ghost">✦</span> SNAPPLUS <span className="tag">DÉMO NON OFFICIELLE</span></div>
      <section className="hero">
        <div className="orb orb1" /><div className="orb orb2" />
        <div className="heroInner">
          <div className="eyebrow">✨ EXPÉRIENCE DE DÉMONSTRATION</div>
          <div className="logo">S<span>+</span></div>
          <h1>Découvre une expérience <em>premium.</em></h1>
          <p className="lead">Une maquette interactive inspirée des pages de présentation d'abonnements, créée pour tester un design moderne.</p>
          <button className="primary" onClick={() => { setStep(1); document.getElementById("demo")?.scrollIntoView({ behavior: "smooth" }); }}>Découvrir la démo <b>→</b></button>
          <div className="trust"><span>✦</span> Démonstration uniquement · Aucun compte requis</div>
        </div>
        <div className="phone" aria-label="Aperçu de l'interface">
          <div className="phoneTop"><i /> <i /> <i /></div>
          <div className="phoneIcon">S<span>+</span></div>
          <div className="phoneTitle">PLUS<br/>D'OPTIONS.</div>
          <div className="phoneLine" />
          <div className="miniCards"><div>✦</div><div>◉</div><div>♡</div></div>
          <div className="phoneCaption">UNE EXPÉRIENCE À TON IMAGE</div>
        </div>
      </section>

      <section className="features">
        <div className="sectionLabel">POUR EXPLORER</div>
        <h2>Une interface qui fait<br/><em>la différence.</em></h2>
        <div className="featureGrid">
          {features.map(([icon, title, desc]) => <article className="feature" key={title}><div className="featureIcon">{icon}</div><h3>{title}</h3><p>{desc}</p></article>)}
        </div>
      </section>

      <section className="demo" id="demo">
        <div className="sectionLabel">PARCOURS INTERACTIF</div>
        <h2>Teste la <em>démo.</em></h2>
        <p className="demoLead">Parcours les écrans de démonstration. Aucun identifiant, numéro de téléphone ou code de vérification ne sera demandé.</p>
        <div className="wizard">
          <div className="progress"><span className={step >= 0 ? "active" : ""}/><span className={step >= 1 ? "active" : ""}/><span className={step >= 2 ? "active" : ""}/></div>
          {step === 0 && <div className="wizardBody"><div className="bigIcon">✨</div><h3>Bienvenue dans la démo</h3><p>Découvre le parcours de présentation en quelques secondes.</p><button className="primary full" onClick={() => setStep(1)}>Commencer <b>→</b></button></div>}
          {step === 1 && <div className="wizardBody"><div className="bigIcon">🎨</div><h3>Personnalise ton aperçu</h3><p>Choisis une ambiance visuelle pour prévisualiser l'interface.</p><div className="themes"><button onClick={e => e.currentTarget.classList.toggle("chosen")}>☀️ Lumineux</button><button onClick={e => e.currentTarget.classList.toggle("chosen")}>🌙 Sombre</button></div><button className="primary full" onClick={() => setStep(2)}>Continuer <b>→</b></button></div>}
          {step === 2 && <div className="wizardBody"><div className="bigIcon">🎉</div><h3>Démo terminée !</h3><p>Tu as parcouru les écrans de démonstration. Aucune activation ni connexion à un service tiers n'a été effectuée.</p><button className="primary full" onClick={() => setStep(0)}>Recommencer ↺</button></div>}
          <div className="wizardFoot">MAQUETTE DE DÉMONSTRATION · AUCUNE DONNÉE COLLECTÉE</div>
        </div>
      </section>
      <footer><div className="footerLogo">S<span>+</span> SNAPPLUS</div><p>Projet de démonstration indépendant. Non affilié à Snapchat ou Snap Inc.</p><button className="textButton" onClick={() => setShowInfo(!showInfo)}>À propos de cette démo</button>{showInfo && <p className="about">Cette interface est une maquette front-end. Elle n'offre aucun abonnement et ne se connecte à aucun compte.</p>}</footer>
    </main>
  );
}
