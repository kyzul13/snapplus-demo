import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SnapPlus — Démo non officielle",
  description: "Maquette interactive de démonstration, sans connexion ni collecte de données.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fr"><body>{children}</body></html>;
}
