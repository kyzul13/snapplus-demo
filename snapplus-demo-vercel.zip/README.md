# SnapPlus — maquette de démonstration

Projet Next.js prêt à déployer sur Vercel.

## Lancer en local
1. Installe Node.js (version 18 ou plus récente).
2. Dans ce dossier, lance `npm install`.
3. Lance `npm run dev`.
4. Ouvre http://localhost:3000.

## Déployer sur Vercel
1. Crée un dépôt GitHub et ajoute tous les fichiers de ce projet.
2. Connecte-toi à https://vercel.com et choisis **Add New → Project**.
3. Importe le dépôt GitHub.
4. Garde les paramètres détectés par Vercel, puis clique sur **Deploy**.

## Important
Cette interface est une maquette indépendante. Elle n'est pas affiliée à Snap Inc. ou Snapchat, ne propose pas d'abonnement Snapchat+, ne demande aucun identifiant ou code SMS et ne collecte aucune donnée.
